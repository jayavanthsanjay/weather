import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Weather & Air Quality',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: WeatherPage(),
    );
  }
}

class WeatherPage extends StatefulWidget {
  @override
  _WeatherPageState createState() => _WeatherPageState();
}

class _WeatherPageState extends State<WeatherPage> {
  String temperature = '';
  String humidity = '';
  String aqi = '';

  Future<void> fetchWeatherAndAirQuality() async {
    // You need to replace these URLs with the actual API endpoints and your API keys
    final weatherUrl =
        'https://api.openweathermap.org/data/2.5/weather?q=Chennai&appid=77eff6d64bc010f8dca000b1aeb2c806';
    final airQualityUrl =
        'https://api.airvisual.com/v2/Chennai?key=88877e6f-aa2f-422b-b600-25c47e2437f7';

    // Fetch weather data
    final weatherResponse = await http.get(Uri.parse(weatherUrl));
    final weatherData = json.decode(weatherResponse.body);
    setState(() {
      temperature = (weatherData['main']['temp'] - 273.15)
          .toStringAsFixed(1); // Convert from Kelvin to Celsius
      humidity = weatherData['main']['humidity'].toString();
    });

    // Fetch air quality data
    final airQualityResponse = await http.get(Uri.parse(airQualityUrl));
    final airQualityData = json.decode(airQualityResponse.body);
    setState(() {
      aqi = airQualityData['data']['current']['pollution']['aqius'].toString();
    });
  }

  @override
  void initState() {
    super.initState();
    fetchWeatherAndAirQuality();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Weather & Air Quality'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Temperature: $temperature °C',
              style: TextStyle(fontSize: 20),
            ),
            Text(
              'Humidity: $humidity%',
              style: TextStyle(fontSize: 20),
            ),
            Text(
              'AQI: $aqi',
              style: TextStyle(fontSize: 20),
            ),
          ],
        ),
      ),
    );
  }
}
